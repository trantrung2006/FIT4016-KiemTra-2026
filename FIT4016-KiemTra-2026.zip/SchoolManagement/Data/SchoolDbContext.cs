// DbContext configuration for School Management database
using Microsoft.EntityFrameworkCore;
using SchoolManagement.Models;

namespace SchoolManagement.Data
{
    public class SchoolDbContext : DbContext
    {
        public DbSet<School> Schools => Set<School>();
        public DbSet<Student> Students => Set<Student>();

        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlServer("Server=.;Database=SchoolManagement;Trusted_Connection=True;TrustServerCertificate=True");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<School>().HasIndex(s => s.Name).IsUnique();
            modelBuilder.Entity<Student>().HasIndex(s => s.StudentCode).IsUnique();
            modelBuilder.Entity<Student>().HasIndex(s => s.Email).IsUnique();
        }
    }
}
