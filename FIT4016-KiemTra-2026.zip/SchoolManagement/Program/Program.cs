// Application entry point and demo execution
using SchoolManagement.Services;
using SchoolManagement.Models;

var service = new StudentService();

try
{
    service.GetStudents(1);

    service.CreateStudent(new Student
    {
        FullName = "John Doe",
        StudentCode = "STU9999",
        Email = "john.doe@gmail.com",
        Phone = "0987654321",
        SchoolId = 1
    });

    service.UpdateStudent(1, new Student
    {
        FullName = "Updated Name",
        Email = "updated@gmail.com",
        Phone = "0123456789",
        SchoolId = 2
    });

    service.DeleteStudent(2);
}
catch (Exception ex)
{
    Console.WriteLine($"Error: {ex.Message}");
}
