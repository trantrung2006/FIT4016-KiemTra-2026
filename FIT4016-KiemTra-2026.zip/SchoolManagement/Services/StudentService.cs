// Service class handling CRUD operations for students
using Microsoft.EntityFrameworkCore;
using SchoolManagement.Data;
using SchoolManagement.Models;
using System.Text.RegularExpressions;

namespace SchoolManagement.Services
{
    public class StudentService
    {
        private readonly SchoolDbContext _context = new();

        // CREATE
        public void CreateStudent(Student student)
        {
            ValidateStudent(student, isCreate: true);

            _context.Students.Add(student);
            _context.SaveChanges();

            Console.WriteLine("Student created successfully.");
        }

        // READ with pagination
        public void GetStudents(int page = 1)
        {
            int pageSize = 10;

            var students = _context.Students
                .Include(s => s.School)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            Console.WriteLine("Full Name | Student ID | Email | Phone | School");

            foreach (var s in students)
            {
                Console.WriteLine($"{s.FullName} | {s.StudentCode} | {s.Email} | {s.Phone} | {s.School.Name}");
            }
        }

        // UPDATE
        public void UpdateStudent(int id, Student updated)
        {
            var student = _context.Students.Find(id)
                ?? throw new Exception("Student not found.");

            student.FullName = updated.FullName;
            student.Email = updated.Email;
            student.Phone = updated.Phone;
            student.SchoolId = updated.SchoolId;
            student.UpdatedAt = DateTime.Now;

            ValidateStudent(student, isCreate: false);

            _context.SaveChanges();
            Console.WriteLine("Student updated successfully.");
        }

        // DELETE
        public void DeleteStudent(int id)
        {
            var student = _context.Students.Find(id)
                ?? throw new Exception("Student not found.");

            _context.Students.Remove(student);
            _context.SaveChanges();

            Console.WriteLine("Student deleted successfully.");
        }

        // VALIDATION
        private void ValidateStudent(Student student, bool isCreate)
        {
            if (string.IsNullOrWhiteSpace(student.FullName) || student.FullName.Length < 2)
                throw new Exception("Full name must be between 2 and 100 characters.");

            if (isCreate && _context.Students.Any(s => s.StudentCode == student.StudentCode))
                throw new Exception("Student ID already exists.");

            if (!Regex.IsMatch(student.Email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                throw new Exception("Invalid email format.");

            if (_context.Students.Any(s => s.Email == student.Email && s.Id != student.Id))
                throw new Exception("Email already exists.");

            if (!string.IsNullOrEmpty(student.Phone) &&
                !Regex.IsMatch(student.Phone, @"^\d{10,11}$"))
                throw new Exception("Phone number must be 10-11 digits.");

            if (!_context.Schools.Any(s => s.Id == student.SchoolId))
                throw new Exception("Selected school does not exist.");
        }
    }
}
